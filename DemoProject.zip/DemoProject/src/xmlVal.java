import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.path.json.JsonPath;
import io.restassured.path.xml.XmlPath;

import static io.restassured.RestAssured.*;
import static org.hamcrest.Matchers.*;

import org.testng.Assert;

import files.ReUsableMethods;
import files.payload;

public class xmlVal {

	public static void main(String[] args) {

		//given - all input details 
		//when - Submit the API -resource,http method
		//Then - validate the response
		RestAssured.baseURI= "https://geoserver.imsvas.com";
		
		String getPlaceResponse=given()
		.accept(ContentType.XML)
		.when()
		.get("/geoserver/gcw/ows?service=WFS&version=1.0.0&request=getfeature&typename=gcw:gcwdata&CQL_FILTER=threat=3")
		.then()
		.assertThat()
		.log().all().extract().response().asString();
		
		XmlPath x1=new XmlPath(getPlaceResponse);
		String actualAddress =x1.getString("FeatureCollection.@xmlns");
		String actualAddress1 =x1.getString("FeatureCollection.featureMember[0].gcwdata.@fid");
		String actualAddress2 =x1.getString("FeatureCollection.boundedBy[0].Box.@srsName");
		System.out.println("url ---------------"+actualAddress);
		System.out.println("fid ---------------"+actualAddress1);
		System.out.println("srsname ---------------"+actualAddress2);
		
		
		
		
		
		
	}
}